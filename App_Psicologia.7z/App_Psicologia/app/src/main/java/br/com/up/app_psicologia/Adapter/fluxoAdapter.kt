package br.com.up.app_psicologia.Adapter

import android.app.Application
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.RecyclerView
import br.com.up.app_psicologia.Model.nomeTest
import br.com.up.app_psicologia.R
import br.com.up.app_psicologia.TestActivity
import kotlin.reflect.KClass

class fluxoAdapter(private val nomeTestList:List<nomeTest>) : RecyclerView.Adapter<fluxoAdapter.fluxoViewHolder>() {

    inner class fluxoViewHolder(item: View) : RecyclerView.ViewHolder(item){

        init {
            item.setOnClickListener {
                val position = adapterPosition
                val test = nomeTestList[position]

                val intent = Intent(TestActivity::class)
                startActivity(intent)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): fluxoViewHolder {
        val inflater = LayoutInflater.from(parent.context)

        val layout = inflater
            .inflate(
                R.layout.view_tests_nome,
                parent,
                false
            )

        return fluxoViewHolder(layout)
    }

    override fun onBindViewHolder(holder: fluxoViewHolder, position: Int) {
        TODO("Not yet implemented")
    }

    override fun getItemCount(): Int {
        return  nomeTestList.size
    }
}
package br.com.up.app_psicologia.Model

class nomeTest (
    var nome : String,
    var quantidade : Int,
    var sigla : String,
    var constuto : String,
    var contexto : String,
    var idade : String,
    var aplicacao : String,
    var tempoAp : String,
    var correcao : String,
    var validade : String,
    var objetivo : String,
    var pubAlvo : String,
    var descricao : String,
    var itens : String,
    var profissionais : String
)
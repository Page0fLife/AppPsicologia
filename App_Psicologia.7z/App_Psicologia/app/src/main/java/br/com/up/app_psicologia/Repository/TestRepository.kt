package br.com.up.app_psicologia.Repository

import br.com.up.app_psicologia.Model.nomeTest

class TestRepository {

    companion object{
        private var repository : TestRepository? = null

        fun instance():TestRepository {
            if(repository == null){
                repository = TestRepository()
            }
            return repository!!
        }
    }

    fun save(teste : nomeTest){
        val database = Firebase.firestore
        database.collection("teste").add(teste)
    }

    fun delete(teste : nomeTest){
        val database = Firebase.firestore
        database.collection("teste").document(teste.nome!!).delete()
    }

    fun getAll(callback: (List<Test>) -> Unit){

        val database = Firebase.firestore
        database.collection("corrida").get().addOnSuccessListener { documents ->
            val races = arrayListOf<Test>()
            for (document in documents) {
                val race = Test(
                    quantidade = document.quantidade,
                    nome = document.get("nome").toString(),
                    sigla = document.get("sigla").toString(),
                    contexto = document.get("contexto").toString(),
                    idade = document.getTimestamp("idade")!!,
                    aplicacao = document.getDouble("aplicacao")!!.toFloat()
                )
                races.add(race)
            }
            callback(races)
        }

    }


}